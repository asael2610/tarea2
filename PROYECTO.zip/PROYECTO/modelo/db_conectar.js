import mysql from 'mysql'
var conectar = mysql.createConnection ({

host :'localhost',
user :'usr_empresa',
password :'Empres@123',
database : 'db_empresa',
port : '3307'

});

conectar.connect(function(err){

    if(err){
console.error('error en la conexion'+ err.stack)
return;
    }

console.log('conexion exitosa ID: ' + conectar.threadId);

});

export {conectar}  